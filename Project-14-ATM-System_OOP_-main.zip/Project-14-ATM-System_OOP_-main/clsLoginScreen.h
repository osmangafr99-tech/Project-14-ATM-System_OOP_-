#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include "clsMainScreen.h"

using namespace std;

class clsLoginScreen : protected clsScreen
{
	static bool _Login()
	{
		string AccountNumber, PinCode;
		bool LoginFailed = false;
		short FailedLoginCount = 0;

		do
		{
			if (LoginFailed)
			{
				FailedLoginCount++;

				cout << "\nInvalid UserName/Password!\n";
				cout << "You have " << (3 - FailedLoginCount) << " Trail(s) to Login.\n\n";
			}

			if (FailedLoginCount == 3)
			{
				cout << "\nYou are Locked after 3 failed trails\n\n";
				return false;
			}

			cout << "Enter AccountNumber ? ";
			cin >> AccountNumber;

			cout << "Enter PIN Code ? ";
			cin >> PinCode;

			CurrentClient = clsBankClient::Find(AccountNumber, PinCode);

			LoginFailed = CurrentClient.IsEmpty();

		} while (LoginFailed);

		CurrentClient.RegisterLogin();

		clsMainScreen::ShowMainMenue();
		return true;
	}

public:

	static bool ShowLoginScreen()
	{
		system("cls");
		_DrawScreenHeader("\t    Login Screen");
		return _Login();
	}
};

