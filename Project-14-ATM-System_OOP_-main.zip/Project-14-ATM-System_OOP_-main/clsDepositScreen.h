#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include "clsInputValidate.h"

using namespace std;

class clsDepositScreen : protected clsScreen
{
	static double _ReadDepositAmount()
	{
		cout << "\nPlease Enter Deposit Amount ? ";
		double Amount = clsInputValidate::ReadDblNumber();
		return Amount;
	}

public:

	static void ShowDepositScreen()
	{
		system("cls");
		_DrawScreenHeader("\t  Deposit Screen");

		double Amount = _ReadDepositAmount();

		cout << "\nAre you sure you want to Perform this Transaction?  Y/N? ";
		char Answer = 'n';
		cin >> Answer;

		if (Answer == 'Y' || Answer == 'y')
		{
			CurrentClient.Deposite(Amount);
			cout << "\nAmount Deposited Successfully.\n";
			cout << "\nNew Balance is : " << CurrentClient.AccountBalance << "\n\n";
		}
		else
		{
			cout << "\nOperation was Cancelled!\n\n";
		}
	}
};

