@echo off
echo ================================
echo  Git Auto Commit & Push (main)
echo ================================

set /p msg=Enter commit message: 

git add .
git commit -m "%msg%"
git push origin main

echo.
echo ================================
echo  Done Successfully 🚀
echo ================================
pause
