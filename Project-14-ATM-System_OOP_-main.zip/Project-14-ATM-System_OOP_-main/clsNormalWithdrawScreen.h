#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include "clsInputValidate.h"

using namespace std;

class clsNormalWithdrawScreen : protected clsScreen
{
	static double _ReadWithdrawAmount()
	{
		cout << "\nPlease Enter Withdraw Amount ? ";
		double Amount = clsInputValidate::ReadDblNumber();
		return Amount;
	}

public:

	static void ShowNormalWithdrawScreen()
	{
		system("cls");
		_DrawScreenHeader("\tNormal Withdraw Screen");

		double Amount = _ReadWithdrawAmount();

		cout << "\nAre you sure you want to perform this Transaction ? Y/N? ";
		char Answer = 'n';
		cin >> Answer;

		if (Answer == 'Y' || Answer == 'y')
		{
			if (CurrentClient.Withdraw(Amount))
			{
				cout << "\nAmount Withdrew Successfully.\n";
				cout << "\nNew Balance is : " << CurrentClient.AccountBalance << "\n\n";
			}
			else
			{
				cout << "\nCannot Withdraw, Insuffecient Balance!\n";
				cout << "\nAmount to Withdraw is : " << Amount;
				cout << "\nYour Balance is : " << CurrentClient.AccountBalance << "\n\n";
			}
		}
		else
		{
			cout << "\nOperation was Cancelled!\n\n";
		}
	}
};

