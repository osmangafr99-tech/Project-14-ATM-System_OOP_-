#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"

using namespace std;

class clsQuickWithdawScreen : protected clsScreen
{
	enum enQuickWithdrawMenueOptions
	{ 
		e20 = 1, e50 = 2, e100 = 3, e200 = 4, e400 = 5, e600 = 6, e800 = 7, 
		e1000 = 8, eShowMainMenue = 9 
	};

	static short _ReadQuickWithdawMenueOption()
	{
		cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 9]? ";
		short Choice = clsInputValidate::ReadShortNumberBetween(1, 9, "Enter Number between 1 to 9? ");
		return Choice;
	}

	static short _GetQuickWithdrawAmount(enQuickWithdrawMenueOptions QuickWithdrawMenueOption)
	{
		switch (QuickWithdrawMenueOption)
		{
		case clsQuickWithdawScreen::e20:
			return 20;
		case clsQuickWithdawScreen::e50:
			return 50;
		case clsQuickWithdawScreen::e100:
			return 100;
		case clsQuickWithdawScreen::e200:
			return 200;
		case clsQuickWithdawScreen::e400:
			return 400;
		case clsQuickWithdawScreen::e600:
			return 600;
		case clsQuickWithdawScreen::e800:
			return 800;
		case clsQuickWithdawScreen::e1000:
			return 1000;
		}
	}

	static void _PerformQuickWithdrawMenueOption(enQuickWithdrawMenueOptions QuickWithdrawMenueOption)
	{
		if (QuickWithdrawMenueOption == enQuickWithdrawMenueOptions::eShowMainMenue)
		{
			return;
		}

		short Amount = _GetQuickWithdrawAmount(QuickWithdrawMenueOption);
		
		cout << "\nAre you sure you want to perform this Transaction ? Y/N? ";
		char Answer = 'n';
		cin >> Answer;

		if (Answer == 'Y' || Answer == 'y')
		{
			if (CurrentClient.Withdraw(Amount))
			{
				cout << "\nAmount Withdrew Successfully.\n";
				cout << "\nNew Balance is : " << CurrentClient.AccountBalance << "\n\n";
			}
			else
			{
				cout << "\nCannot Withdraw, Insuffecient Balance!\n";
				cout << "\nAmount to Withdraw is : " << Amount;
				cout << "\nYour Balance is : " << CurrentClient.AccountBalance << "\n\n";
			}
		}
		else
		{
			cout << "\nOperation was Cancelled!\n\n";
		}
	}

public:

	static void ShowQuickWithdrawMenue()
	{
		system("cls");
		_DrawScreenHeader("\tQuick Withdraw Screen");

		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t\tQuick Withdraw Menue\n";
		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t[1] 20 \t\t[2] 50\n";
		cout << setw(37) << left << "" << "\t[3] 100\t\t[4] 200\n";
		cout << setw(37) << left << "" << "\t[5] 400\t\t[6] 600\n";
		cout << setw(37) << left << "" << "\t[7] 800\t\t[8] 1000\n";
		cout << setw(37) << left << "" << "\t[9] Main Menue.\n";
		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "Your Balance is " << CurrentClient.AccountBalance << endl;

		_PerformQuickWithdrawMenueOption(enQuickWithdrawMenueOptions(_ReadQuickWithdawMenueOption()));
	}
};

