#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include "clsInputValidate.h"
#include "clsBankClient.h"

using namespace std;

class clsTransferScreen : protected clsScreen
{
    static void _PrintClient(clsBankClient& Client)
    {
        cout << "\nClient Card :";
        cout << "\n______________________________";
        cout << "\nFull Name   : " << Client.FullName();
        cout << "\nAcc. Number : " << Client.GetAccountNumber();
        cout << "\nBalance     : " << Client.AccountBalance;
        cout << "\n______________________________\n";
    }

    static double _ReadAmount()
    {
        cout << "\nPlease enter transfer Amount : ";
        double Amount = clsInputValidate::ReadDblNumber();

        while (Amount > CurrentClient.AccountBalance)
        {
            cout << "\nAmount Exceeds the available Balance, Enter another Amount ? ";
            Amount = clsInputValidate::ReadDblNumber();
        }

        return Amount;
    }

    static string _ReadAccountNumber(string Word)
    {
        cout << "\nPlease enter Account Number to Transfer " << Word << " : ";
        string AccountNumber = clsInputValidate::ReadString();

        while (!clsBankClient::IsClientExist(AccountNumber))
        {
            cout << "\nAccount Number is not found, choose another one : ";
            AccountNumber = clsInputValidate::ReadString();
        }

        return AccountNumber;
    }

public:

	static void ShowTransferScreen()
	{
        system("cls");
        _DrawScreenHeader("\t    Transfer Screen");

        clsBankClient DestinationClient = clsBankClient::Find(_ReadAccountNumber("to"));
        _PrintClient(DestinationClient);

        double Amount = _ReadAmount();

        cout << "\nAre you sure you want to Perform this Operation?  Y/N? ";
        char Answer = 'n';
        cin >> Answer;

        if (Answer == 'Y' || Answer == 'y')
        {
            if (CurrentClient.Transfer(Amount, DestinationClient))
            {
                cout << "\nTransfer done Successfully\n";

                _PrintClient(CurrentClient);
                _PrintClient(DestinationClient);
            }
            else
            {
                cout << "\nTransfer Failed\n";
            }
        }
        else
        {
            cout << "\nOperation was Cancelled!\n\n";
        }
	}
};

