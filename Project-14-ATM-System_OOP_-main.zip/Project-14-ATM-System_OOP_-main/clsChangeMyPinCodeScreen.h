#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include "clsInputValidate.h"

using namespace std;

class clsChangeMyPinCodeScreen : protected clsScreen
{
	static string _ReadNewPinCode()
	{
		cout << "\nPlease Enter New PIN Code : ";
		string NewPinCode = clsInputValidate::ReadString();
		return NewPinCode;
	}

public:

	static void ShowChangeMyPinCodeScreen()
	{
		system("cls");
		_DrawScreenHeader("\tChange My PIN Code Screen");

		cout << "\n\nUpdate Client PIN Code :";
		cout << "\n_________________\n";

		string NewPinCode = _ReadNewPinCode();

		cout << "\nAre you sure you want to Perform this Operation?  Y/N? ";
		char Answer = 'n';
		cin >> Answer;

		if (Answer == 'Y' || Answer == 'y')
		{
			CurrentClient.UpdatePinCode(NewPinCode);

			cout << "\nPIN Code Updated Successfully :-)\n\n";
		}
		else
		{
			cout << "\nOperation was Cancelled!\n\n";
		}
	}
};

