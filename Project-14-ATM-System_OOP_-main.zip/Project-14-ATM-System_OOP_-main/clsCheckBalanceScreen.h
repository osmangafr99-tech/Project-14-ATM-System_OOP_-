#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"
#include <iomanip>

using namespace std;

class clsCheckBalanceScreen : protected clsScreen
{
	static void _ShowBalance()
	{
		cout << setw(37) << left << "" << "==============================================\n";
		cout << setw(50) << left << "" << "Your Balance is :\n";
		cout << setw(55) << left << "" << CurrentClient.AccountBalance << "\n";
		cout << setw(37) << left << "" << "==============================================\n\n";
	}

public:

	static void ShowCheckBalanceScreen()
	{
		system("cls");
		_DrawScreenHeader("\tCheck Balance Screen");
		_ShowBalance();
	}
};

