#pragma once
#include <iostream>
#include "clsScreen.h"
#include "Global.h"

using namespace std;

class clsClientInformationScreen : protected clsScreen
{
    static void _PrintClient()
    {
        cout << setw(40) << left << "" << "===================================\n";
        cout << setw(40) << left << "" << "Client Card :\n";
        cout << setw(40) << left << "" << "===================================\n";
        cout << setw(40) << left << "" << "First Name     : " << CurrentClient.GetFirstName() << "\n";
        cout << setw(40) << left << "" << "Last Name      : " << CurrentClient.GetLastName() << "\n";
        cout << setw(40) << left << "" << "Full Name      : " << CurrentClient.FullName() << "\n";
        cout << setw(40) << left << "" << "Email          : " << CurrentClient.GetEmail() << "\n";
        cout << setw(40) << left << "" << "Phone          : " << CurrentClient.GetPhone() << "\n";
        cout << setw(40) << left << "" << "Account Number : " << CurrentClient.GetAccountNumber() << "\n";
        cout << setw(40) << left << "" << "Acc. Balance   : " << CurrentClient.AccountBalance << "\n";
        cout << setw(40) << left << "" << "===================================\n\n";
    }

public:

	static void ShowClientInformationScreen()
	{
		system("cls");
		_DrawScreenHeader("\tShow My Information Screen");
        _PrintClient();
	}
};

