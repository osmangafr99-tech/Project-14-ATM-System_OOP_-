#pragma once
#include <iostream>
#include <iomanip>
#include "clsScreen.h"
#include "clsInputValidate.h"
#include "clsQuickWithdawScreen.h"
#include "clsNormalWithdrawScreen.h"
#include "clsDepositScreen.h"
#include "clsCheckBalanceScreen.h"
#include "clsChangeMyPinCodeScreen.h"
#include "clsClientInformationScreen.h"
#include "clsTransferScreen.h"
#include "clsCurrencyExchangeMainScreen.h"
#include "Global.h"

using namespace std;

class clsMainScreen : protected clsScreen
{
	enum enMainMenueOptions
	{
		eQuickWithdraw = 1, eNormalWithdraw = 2, eDeposit = 3, eTransfer = 4, eCheckBalance = 5,
		eChangeMyPinCode = 6, eShowMyInformation = 7, eCurrencyExchange = 8, eLogout = 9
	};

	static short _ReadMainMenueOption()
	{
		cout << setw(37) << left << "" << "Choose what do you want to do? [1 to 9]? ";
		short Choice = clsInputValidate::ReadShortNumberBetween(1, 9, "Enter Number between 1 to 9? ");
		return Choice;
	}

	static void _GoBackToMainMenue()
	{
		cout << "\n\tPress any key to go back to Main Menue...\n";

		system("pause>0");
		ShowMainMenue();
	}

	static void _ShowQuickWithdrawMenue()
	{
		// cout << "\nQuick Withdraw Menue will be here...\n";
		clsQuickWithdawScreen::ShowQuickWithdrawMenue();
	}

	static void _ShowNormalWithdrawScreen()
	{
		// cout << "\nNormal Withdraw Screen will be here...\n";
		clsNormalWithdrawScreen::ShowNormalWithdrawScreen();
	}

	static void _ShowDepositScreen()
	{
		// cout << "\nDeposit Screen will be here...\n";
		clsDepositScreen::ShowDepositScreen();
	}

	static void _ShowTransferScreen()
	{
		clsTransferScreen::ShowTransferScreen();
	}

	static void _ShowCheckBalanceScreen()
	{
		// cout << "\nCheck Balance Screen will be here...\n";
		clsCheckBalanceScreen::ShowCheckBalanceScreen();
	}

	static void _ShowChangeMyPinScreen()
	{
		// cout << "\nChange My PIN Code Screen will be here...\n";
		clsChangeMyPinCodeScreen::ShowChangeMyPinCodeScreen();
	}

	static void _ShowClientInformationScreen()
	{
		// cout << "\nShow My Information Screen will be here...\n";
		clsClientInformationScreen::ShowClientInformationScreen();
	}

	static void _ShowCurrencyExchangeMainScreen()
	{
		clsCurrencyExchangeMainScreen::ShowCurrenciesMenue();
	}

	//static void _ShowLogoutScreen()
	//{
	//	cout << "\nLogout Screen will be here...\n";
	//}

	static void _Logout()
	{
		CurrentClient = clsBankClient::Find("", "");
	}

	static void _PerformMainMenueOption(enMainMenueOptions	MainMenueOption)
	{
		switch (MainMenueOption)
		{
		case enMainMenueOptions::eQuickWithdraw:
			system("cls");
			_ShowQuickWithdrawMenue();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eNormalWithdraw:
			system("cls");
			_ShowNormalWithdrawScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eDeposit:
			system("cls");
			_ShowDepositScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eTransfer:
			system("cls");
			_ShowTransferScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eCheckBalance:
			system("cls");
			_ShowCheckBalanceScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eChangeMyPinCode:
			system("cls");
			_ShowChangeMyPinScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eShowMyInformation:
			system("cls");
			_ShowClientInformationScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eCurrencyExchange:
			system("cls");
			_ShowCurrencyExchangeMainScreen();
			_GoBackToMainMenue();
			break;

		case enMainMenueOptions::eLogout:
			_Logout();
			break;
		}
	}

public:

	static void ShowMainMenue()
	{
		system("cls");
		_DrawScreenHeader("\t\tMain Screen");

		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t\t\tMain Menue\n";
		cout << setw(37) << left << "" << "===========================================\n";
		cout << setw(37) << left << "" << "\t [1] Quick Withdraw.\n";
		cout << setw(37) << left << "" << "\t [2] Normal Withdraw.\n";
		cout << setw(37) << left << "" << "\t [3] Deposit.\n";
		cout << setw(37) << left << "" << "\t [4] Transfer.\n";
		cout << setw(37) << left << "" << "\t [5] Check Balance.\n";
		cout << setw(37) << left << "" << "\t [6] Change My PIN Code.\n";
		cout << setw(37) << left << "" << "\t [7] Show My Information.\n";
		cout << setw(37) << left << "" << "\t [8] Currency Exchange.\n";
		cout << setw(37) << left << "" << "\t [9] Logout.\n";
		cout << setw(37) << left << "" << "===========================================\n";

		_PerformMainMenueOption(enMainMenueOptions(_ReadMainMenueOption()));
	}
};

